import argparse, os, sys
from glob import glob
from pystyle import Colorate, Colors


def printf(category, msg, color, endf='\n', debug_arg=False, quiet_arg=False):
    if not quiet_arg:
        if category == 'DEBUG':
            if debug_arg:
                print(Colorate.Horizontal(color,f'[DEBUG]'), end='')
                print(f' {msg}', end=endf)
        else:
            print(Colorate.Horizontal(color, f'[{category}]'), end='')
            print(f' {msg}', end=endf)

parser = argparse.ArgumentParser(
        description='Tools for Linux 0.0.1',
        epilog='Si utilizas el argumento -q (--quiet) no podras ver porqué falló esta herramienta, si usas zsh con algun tema podrás ver el codigo de error, puedes verlos si vuelves a ejecutar el programa con el argumento -ec')
parser.add_argument('-e', '--edit', action='store', dest='edit', help='Editar algun archivo de configuracion (dotfile), de .config')
parser.add_argument('-ec', '--error-codes',action='store_true',dest='ec',help='Muestra la documentacion de codigos de salida')
parser.add_argument('-q','--quiet', action='store_true', dest='quiet', default=False, help='Oculta mensajes')
parser.add_argument('-d','--debug',action='store_true',dest='debug',default=False,help='Muestra textos para encontrar errores')
parser.add_argument('-f','--file',action='store',dest='file',default=None,help='Especifica un archivo')
parser.add_argument('--seteditor', action='store', dest='editor', default='nano', help='Define un editor para editar algun archivo si es necesario, por defecto nano')
parser.add_argument('--set-conf-folder', action='store', dest='folder', default='.config', help=f'Especifica una carpeta en donde se encuentran los archivos de configuracion, por defecto {os.path.join("/home",os.getenv("USER"),".config")}')
arguments = parser.parse_args()
if __name__ == '__main__':
    from modules.func_edit import edit_main
    if arguments.edit != None:
        edit_main(arguments,printf,parser)
        sys.exit()
    parser.print_help()
